import { Router } from 'express';
import axios from 'axios';
import https from 'https';
import fs from 'fs';
import path from 'path';
import config from '../../config.js';
import logger from '../../utils/logger.js';
import { upload } from '../middleware/multer.js';

const router = Router();
const agent = new https.Agent({ rejectUnauthorized: false });

// ========== مساعدات ==========

// توليد اسم ملف آمن
function safeFilename(url: string): string {
    try {
        const urlObj = new URL(url);
        let name = path.basename(urlObj.pathname) || 'download';
        // إزالة الأحرف الخطرة
        name = name.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_');
        // إضافة timestamp إذا لم يكن هناك اسم
        if (!name || name === '.' || name === '_') {
            name = `download_${Date.now()}`;
        }
        return name;
    } catch {
        return `download_${Date.now()}`;
    }
}

// التحقق من نوع الملف المسموح به
function isAllowedFile(filename: string): boolean {
    const allowed = ['.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm', '.m3u8', '.ts'];
    const ext = path.extname(filename).toLowerCase();
    return allowed.includes(ext);
}

// التحقق من وجود الملف وتوليد اسم فريد
function getUniqueFilepath(dir: string, filename: string): string {
    let filepath = path.join(dir, filename);
    let counter = 1;
    const ext = path.extname(filename);
    const base = path.basename(filename, ext);

    while (fs.existsSync(filepath)) {
        filepath = path.join(dir, `${base}_${counter}${ext}`);
        counter++;
    }
    return filepath;
}

// ========== Routes ==========

// رفع ملف محلي
router.post("/api/upload", upload.single("file"), (req, res) => {
    if (!req.file) {
        return res.status(400).json({
            success: false,
            message: "No file provided"
        });
    }

    res.json({
        success: true,
        message: "File uploaded successfully",
        filename: req.file.filename,
        size: req.file.size
    });
});

// تحميل ملف عن بُعد مع progress
router.post("/api/remote_upload", upload.single("link"), async (req, res) => {
    const link = req.body.link;

    // التحقق من الرابط
    if (!link || typeof link !== 'string') {
        return res.status(400).json({
            success: false,
            message: "No link provided"
        });
    }

    // التحقق من صحة الرابط
    let urlObj: URL;
    try {
        urlObj = new URL(link);
        if (!['http:', 'https:'].includes(urlObj.protocol)) {
            throw new Error('Invalid protocol');
        }
    } catch {
        return res.status(400).json({
            success: false,
            message: "Invalid URL"
        });
    }

    const filename = safeFilename(link);

    // التحقق من نوع الملف
    if (!isAllowedFile(filename)) {
        return res.status(400).json({
            success: false,
            message: "File type not allowed. Allowed: mp4, mkv, avi, mov, wmv, flv, webm, m3u8, ts"
        });
    }

    const filepath = getUniqueFilepath(config.videosDir, filename);
    let writer: fs.WriteStream | null = null;
    let downloaded = 0;
    let totalSize = 0;
    let lastProgressSent = -1;

    try {
        // التحقق من الملف أولاً
        const headResponse = await axios.head(link, {
            httpsAgent: agent,
            timeout: 10000, // 10 ثواني
            maxRedirects: 5
        });

        totalSize = parseInt(String(headResponse.headers['content-length'] || 0), 10);

        // التحقق من حجم الملف (مثلاً 2GB كحد أقصى)
        const MAX_SIZE = 2 * 1024 * 1024 * 1024; // 2GB
        if (totalSize > MAX_SIZE) {
            return res.status(413).json({
                success: false,
                message: `File too large. Max size: ${MAX_SIZE / 1024 / 1024 / 1024}GB`
            });
        }

        logger.info(`Starting remote download: ${filename} (${totalSize > 0 ? (totalSize / 1024 / 1024).toFixed(2) + 'MB' : 'unknown size'})`);

        // بدء التحميل
        const response = await axios.get(link, {
            responseType: "stream",
            httpsAgent: agent,
            timeout: 30000, // 30 ثانية
            maxRedirects: 5,
            onDownloadProgress: (progressEvent) => {
                downloaded = progressEvent.loaded;
                if (totalSize > 0) {
                    const percent = Math.round((downloaded * 100) / totalSize);
                    if (percent - lastProgressSent >= 5) { // كل 5%
                        lastProgressSent = percent;
                        logger.info(`Download progress [${filename}]: ${percent}% (${(downloaded / 1024 / 1024).toFixed(2)}MB / ${(totalSize / 1024 / 1024).toFixed(2)}MB)`);
                    }
                }
            }
        });

        writer = fs.createWriteStream(filepath);

        // معالجة البيانات الواردة
        response.data.on('data', (chunk: Buffer) => {
            downloaded += chunk.length;

            // التحقق من عدم تجاوز الحجم
            if (totalSize > 0 && downloaded > totalSize * 1.1) {
                writer?.destroy();
                fs.unlinkSync(filepath);
                logger.error(`Download exceeded expected size: ${filename}`);
                return;
            }
        });

        response.data.pipe(writer);

        // انتظار الانتهاء
        await new Promise<void>((resolve, reject) => {
            writer!.on("finish", () => {
                const finalSize = fs.statSync(filepath).size;
                logger.info(`Download complete: ${filename} (${(finalSize / 1024 / 1024).toFixed(2)}MB)`);
                resolve();
            });

            writer!.on("error", (err) => {
                reject(err);
            });

            response.data.on('error', (err: Error) => {
                reject(err);
            });
        });

        // نجاح
        const finalSize = fs.statSync(filepath).size;
        res.json({
            success: true,
            message: "Remote file downloaded successfully",
            filename: path.basename(filepath),
            originalName: filename,
            size: finalSize,
            path: filepath
        });

    } catch (err: any) {
        // تنظيف الملف التالف
        if (writer) {
            writer.destroy();
        }
        if (fs.existsSync(filepath)) {
            try {
                fs.unlinkSync(filepath);
                logger.info(`Cleaned up incomplete file: ${filepath}`);
            } catch (cleanupErr) {
                logger.error(`Failed to cleanup file: ${cleanupErr}`);
            }
        }

        // تحديد نوع الخطأ
        let errorMessage = "Error downloading file";
        let statusCode = 500;

        if (err.code === 'ECONNABORTED') {
            errorMessage = "Download timed out";
            statusCode = 504;
        } else if (err.code === 'ENOTFOUND') {
            errorMessage = "Host not found";
            statusCode = 502;
        } else if (err.response) {
            statusCode = err.response.status || 500;
            errorMessage = `Server returned ${statusCode}`;
        }

        logger.error(`Download failed [${filename}]: ${err.message || err}`);
        res.status(statusCode).json({
            success: false,
            message: errorMessage,
            error: err.message || String(err)
        });
    }
});

// الحصول على حالة التحميل (اختياري - للـ frontend)
router.get("/api/upload/status", (req, res) => {
    res.json({
        success: true,
        message: "Upload endpoint is active"
    });
});

export default router;
